# PHP-Login-System
A sample login system with user registration
